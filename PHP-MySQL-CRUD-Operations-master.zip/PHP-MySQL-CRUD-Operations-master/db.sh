#!/bin/bash

# Specify the name of your subdomain
subdomain="secret.devopsassignment2.com"

# Retrieve the secret name from the subdomain and remove trailing dot
secret_name=$(dig +short $subdomain | sed 's/\.$//')

# Check if the secret name was found
if [ -z "$secret_name" ]; then
    echo "Error: Secret name not found for subdomain '$subdomain'."
    exit 1
fi

# Retrieve the ARN of the secret
your_secret_id=$(aws secretsmanager list-secrets --region us-east-1 --query "SecretList[?Name=='$secret_name'].ARN" --output text)

# Check if the secret was found
if [ -z "$your_secret_id" ]; then
    echo "Error: Secret with name '$secret_name' not found."
    exit 1
fi

# Retrieve credentials from Secrets Manager
credentials=$(aws secretsmanager get-secret-value --region us-east-1 --secret-id "$your_secret_id" --query SecretString --output text)

# Extract username and password from credentials
username=$(echo "$credentials" | jq -r '.username')
password=$(echo "$credentials" | jq -r '.password')

# Define file path of config.php
config_file="/var/www/html/frontend/config.php"

# Replace database credentials in config.php
sudo sed -i "s/define(\"DB_USERNAME\", \"[^\"]*\");/define(\"DB_USERNAME\", \"$username\");/" "$config_file"
sudo sed -i "s/define(\"DB_PASSWORD\", \"[^\"]*\");/define(\"DB_PASSWORD\", \"$password\");/" "$config_file"

echo "Database credentials have been updated in $config_file"

# Check if the database already exists
if mysql -h backend.devopsassignment2.com -u "$username" -p"$password" -e "use crud"; then
    echo "Database 'crud' already exists. Skipping creation."
else
    # Create database and restore database dump
    if mysql -h backend.devopsassignment2.com-u "$username" -p"$password" -e "CREATE DATABASE crud"; then
        echo "Database 'crud' created successfully."
        sudo mysql -h backend.devopsassignment2.com-u "$username" -p"$password" crud < /var/www/html/frontend/crud.sql
        if [ $? -eq 0 ]; then
            echo "Database 'crud' restored successfully."
        else
            echo "Error: Failed to restore database 'crud'."
        fi
    else
        echo "Error: Failed to create database 'crud'."
    fi
fi

