#!/bin/bash
export DEBIAN_FRONTEND=noninteractive
sudo apt-get update -qq
sudo apt remove needrestart -y
sudo add-apt-repository -y ppa:ondrej/php
sudo DEBIAN_FRONTEND=noninteractive sudo apt install -qq -o Dpkg::Options::="--force-confnew" php8.0 libapache2-mod-php8.0 php8.0-fpm libapache2-mod-fcgid php8.0-curl php8.0-dev php8.0-gd php8.0-mbstring php8.0-zip php8.0-mysql php8.0-xml php-mysql -y --allow-downgrades
sudo systemctl stop apache2
sudo apt install -qq -o Dpkg::Options::="--force-confnew" software-properties-common apache2 unzip awscli curl net-tools mysql-client jq -y

# Prepare AWS CLI environment
mkdir /home/ubuntu/.aws
touch /home/ubuntu/.aws/config
touch /home/ubuntu/.aws/credentials
sudo sed -i '/^\[default\]/a region = us-east-1' /home/ubuntu/.aws/config

# Fetch secrets from AWS Secrets Manager
SECRET_STRING=$(aws secretsmanager get-secret-value --secret-id db_credentials --query SecretString --output text)
DB_USER=$(echo $SECRET_STRING | jq -r .username)
DB_PASSWORD=$(echo $SECRET_STRING | jq -r .password)
DB_SERVER=$(echo $SECRET_STRING | jq -r .server)
DB_NAME=$(echo $SECRET_STRING | jq -r .dbname)

cd /var/www/html/
sudo git clone https://github.com/Usman7236/crud.git
sudo chown -R ubuntu:ubuntu /var/www/html
sudo chmod 775 /var/www/html/index.html
cd crud
sudo unzip PHP-MySQL-CRUD-Operations-master.zip
mv PHP-MySQL-CRUD-Operations-master frontend
sudo mv frontend ../
sudo cp /var/www/html/frontend/000-default.conf /etc/apache2/sites-available/
sudo chown -R ubuntu:ubuntu /var/www/html
sudo chmod 775 /var/www/html/index.html
cp /var/www/html/frontend/monitor.sh /home/ubuntu/
hostname > /var/www/html/index.html
cp /var/www/html/index.html /var/www/html/frontend/ip.html
sudo chmod -R 777 /var/www/html/frontend/
sudo systemctl restart apache2
cd /var/www/html/frontend/

# Database operations using secrets
mysql -h${DB_SERVER} -u${DB_USER} -p${DB_PASSWORD} -e "CREATE DATABASE IF NOT EXISTS ${DB_NAME};"
mysql -h${DB_SERVER} -u${DB_USER} -p${DB_PASSWORD} ${DB_NAME} < crud.sql

echo "*/5 * * * * /bin/bash /home/ubuntu/monitor.sh" | crontab -
